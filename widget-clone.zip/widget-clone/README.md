## Widget Clone

Purpose: a drop-in, config-driven flow engine you can import into any project, or embed via a script tag. It mirrors the Unison widget functionality while allowing you to create entirely new flows by editing a config file.

### What’s included
- Core engine (`src/`) with DOM renderer and simple state machine
- Config schema (`src/core/types.ts`) and example flow (`flows/exampleFlow.json`)
- Optional webhook integration (`src/integrations/webhook.ts`)
- Dual distribution: ESM import and IIFE standalone bundle
- Demo page in `public/` and an npm-import example in `examples/npm-import/`

### Quick start (script tag)
1. Build:
   ```bash
   npm install
   npm run build
   ```
2. Open `public/index.html` in a browser (or host the `public/` folder). The demo bootstraps the example flow.

### Quick start (npm import)
1. Build once locally:
   ```bash
   npm install
   npm run build
   ```
2. In another project, copy `dist/` into your project or publish this package, then:
   ```ts
   import { createFlowApp } from 'widget-clone';

    createFlowApp({
      container: document.getElementById('app')!,
      flow: {/* your config */},
    });
   ```

### Install
```bash
npm install
```

### Scripts
- `npm run build`: Produces ESM (`dist/index.esm.js`) and IIFE (`dist/standalone.js`) bundles
- `npm run clean`: Removes `dist/`

### Configuration model (high-level)
- Flow is an ordered list of steps
- Each step has:
  - `id`, `title`, `body`
  - `options`: array of choices with `id`, `label`, `next` (branching) and optional `value` payload
  - `kind`: `single` | `multiple` | `info`
- Submission
  - `onSubmit` callback (client) OR `webhook` URL configured in `createFlowApp`

See `src/core/types.ts` for exact types and `flows/exampleFlow.json` for a working instance.

### Webhook integration (optional)
If you provide `webhook: { url, headers? }` to `createFlowApp`, the kit will POST a JSON payload with `answers`, `metadata`, and `flowId`. Retries with exponential backoff are built-in.

### Hostinger + GitHub deployment (static)
1. Build locally: `npm run build`
2. Commit `public/` and `dist/` to your repo (or build in CI and upload artifacts)
3. On Hostinger, deploy the repository and set the site root to the folder that contains `public/`
4. If you only need the embed, host `dist/standalone.js` and reference it from any page

### Usage in a new project
- Copy the entire `widget-clone/` folder into your new repository
- Edit `flows/exampleFlow.json` or create your own in `flows/`
- Update `public/index.html` to point to your flow (change `window.__UNISON_FLOW__`)
- If you need persistence, set the webhook URL in the boot call

### Dev notes (for maintainers)
- Keep public API surface minimal: `createFlowApp`, `types`, and a few helpers
- Never leak PII to logs
- Keep render functions pure and re-runnable (idempotent rebuild on state)
- Keep the IIFE build under ~30KB minified for snappy embeds

### Roadmap (optional)
- Theming system (CSS variables)
- Accessibility review (keyboard + ARIA)
- Analytics hooks (generic event bus)


