export type Option = {
  id: string;
  label: string;
  value?: unknown;
  next?: string | null; // next step id or null to submit
};

export type StepKind = 'single' | 'multiple' | 'info';

export type Step = {
  id: string;
  title: string;
  body?: string;
  kind: StepKind;
  options?: Option[]; // for single/multiple kinds
};

export type Flow = {
  id: string;
  title: string;
  steps: Step[];
  submitLabel?: string;
};

export type Answer = {
  stepId: string;
  optionIds: string[]; // for single, length 1
};

export type WebhookConfig = {
  url: string;
  headers?: Record<string, string>;
  maxRetries?: number;
};

export type CreateFlowAppInput = {
  container: HTMLElement;
  flow: Flow;
  webhook?: WebhookConfig;
  onSubmit?: (payload: SubmissionPayload) => Promise<void> | void;
  cdnBaseUrl?: string; // optional asset base
};

export type SubmissionPayload = {
  flowId: string;
  answers: Answer[];
  metadata: {
    userAgent: string;
    timestamp: string;
    location: { protocol: string; hostname: string; path: string };
  };
};


