import type { Answer, Flow, Option, Step } from './types';

export type EngineState = {
  currentStepId: string;
  answers: Answer[];
};

export function createEngine(flow: Flow) {
  const stepIndex = new Map(flow.steps.map(s => [s.id, s] as const));
  const firstStepId = flow.steps[0]?.id;
  if (!firstStepId) throw new Error('Flow has no steps');

  const state: EngineState = {
    currentStepId: firstStepId,
    answers: [],
  };

  function getCurrent(): Step {
    const step = stepIndex.get(state.currentStepId);
    if (!step) throw new Error(`Unknown step: ${state.currentStepId}`);
    return step;
  }

  function setCurrent(stepId: string): void {
    if (!stepIndex.has(stepId)) throw new Error(`Unknown step: ${stepId}`);
    state.currentStepId = stepId;
  }

  function recordAnswer(stepId: string, optionIds: string[]): void {
    const existing = state.answers.find(a => a.stepId === stepId);
    if (existing) existing.optionIds = optionIds; else state.answers.push({ stepId, optionIds });
  }

  function getOptionById(step: Step, id: string): Option | undefined {
    return step.options?.find(o => o.id === id);
  }

  function getNextFromOption(option: Option | undefined): string | null | undefined {
    return option?.next;
  }

  return {
    state,
    getCurrent,
    setCurrent,
    recordAnswer,
    getOptionById,
    getNextFromOption,
  };
}


