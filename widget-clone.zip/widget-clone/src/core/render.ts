import type { Flow, Step } from './types';
import type { EngineState } from './engine';

export function renderStep(container: HTMLElement, flow: Flow, state: EngineState, onAdvance: (selectedIds: string[]) => void) {
  const step: Step = flow.steps.find(s => s.id === state.currentStepId)!;
  container.innerHTML = '';

  const wrapper = document.createElement('div');
  wrapper.className = 'unison-flow';

  const title = document.createElement('h2');
  title.textContent = step.title;
  wrapper.appendChild(title);

  if (step.body) {
    const body = document.createElement('p');
    body.textContent = step.body;
    wrapper.appendChild(body);
  }

  const selected = new Set<string>();

  if (step.kind !== 'info' && step.options && step.options.length) {
    const list = document.createElement('div');
    list.className = 'options';
    step.options.forEach(opt => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'option';
      btn.textContent = opt.label;
      btn.addEventListener('click', () => {
        if (step.kind === 'single') {
          selected.clear();
          selected.add(opt.id);
          onAdvance([...selected]);
        } else {
          if (selected.has(opt.id)) selected.delete(opt.id); else selected.add(opt.id);
          btn.classList.toggle('selected');
        }
      });
      list.appendChild(btn);
    });
    wrapper.appendChild(list);
  }

  if (step.kind === 'multiple') {
    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'primary';
    next.textContent = flow.submitLabel ?? 'Continue';
    next.addEventListener('click', () => onAdvance([...selected]));
    wrapper.appendChild(next);
  }

  if (step.kind === 'info') {
    const next = document.createElement('button');
    next.type = 'button';
    next.className = 'primary';
    next.textContent = flow.submitLabel ?? 'Continue';
    next.addEventListener('click', () => onAdvance([]));
    wrapper.appendChild(next);
  }

  container.appendChild(wrapper);
}

export function injectBaseStyles() {
  if (document.getElementById('unison-flow-styles')) return;
  const style = document.createElement('style');
  style.id = 'unison-flow-styles';
  style.textContent = `
  .unison-flow{font-family:system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Helvetica Neue, Arial, Noto Color Emoji, Apple Color Emoji, Segoe UI Emoji; max-width:680px; margin:0 auto; padding:16px}
  .unison-flow h2{font-size:24px; margin:0 0 8px}
  .unison-flow p{font-size:16px; color:#333; margin:0 0 16px}
  .unison-flow .options{display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 16px}
  .unison-flow .option{padding:10px 14px; border-radius:8px; border:1px solid #ddd; background:#fff; cursor:pointer}
  .unison-flow .option.selected{background:#eef6ff; border-color:#7cb7ff}
  .unison-flow .primary{padding:12px 16px; border-radius:8px; background:#1f6feb; color:#fff; border:none; cursor:pointer}
  `;
  document.head.appendChild(style);
}


