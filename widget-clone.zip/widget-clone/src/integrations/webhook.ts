import type { SubmissionPayload, WebhookConfig } from '../core/types';

export async function postWithRetry(
  payload: SubmissionPayload,
  webhook: WebhookConfig
): Promise<Response> {
  const maxRetries = webhook.maxRetries ?? 3;
  let attempt = 0;
  let lastError: unknown = null;
  while (attempt <= maxRetries) {
    try {
      const res = await fetch(webhook.url, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(webhook.headers ?? {}),
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`Webhook HTTP ${res.status}`);
      return res;
    } catch (err) {
      lastError = err;
      if (attempt === maxRetries) break;
      const backoffMs = 300 * Math.pow(2, attempt); // 300ms, 600ms, 1200ms...
      await new Promise(r => setTimeout(r, backoffMs));
    }
    attempt++;
  }
  throw lastError instanceof Error ? lastError : new Error('Webhook failed');
}


