import { createEngine } from './core/engine';
import { injectBaseStyles, renderStep } from './core/render';
import { postWithRetry } from './integrations/webhook';
import type { CreateFlowAppInput, SubmissionPayload } from './core/types';

export { type Flow, type Step, type Option } from './core/types';

export function createFlowApp(input: CreateFlowAppInput) {
  const { container, flow, webhook, onSubmit } = input;
  injectBaseStyles();

  const engine = createEngine(flow);

  async function handleAdvance(selectedIds: string[]) {
    const step = engine.getCurrent();
    if (step.kind !== 'info') engine.recordAnswer(step.id, selectedIds);

    // Determine next
    let next: string | null | undefined = null;
    if (selectedIds.length && step.options?.length) {
      // Use first selected for next-hop logic in single/multiple
      const opt = engine.getOptionById(step, selectedIds[0]);
      next = engine.getNextFromOption(opt);
    }

    if (next === null || (!next && !step.options)) {
      // Submit
      const payload: SubmissionPayload = {
        flowId: flow.id,
        answers: engine.state.answers,
        metadata: {
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
          location: {
            protocol: window.location.protocol,
            hostname: window.location.hostname,
            path: window.location.pathname,
          },
        },
      };

      if (webhook) await postWithRetry(payload, webhook);
      if (onSubmit) await onSubmit(payload);

      container.innerHTML = '<div class="unison-flow"><h2>Thanks!</h2><p>Your responses have been submitted.</p></div>';
      return;
    }

    if (next) engine.setCurrent(next);
    else {
      // default to next sequential step
      const idx = flow.steps.findIndex(s => s.id === step.id);
      const fallback = flow.steps[idx + 1]?.id ?? null;
      if (fallback) engine.setCurrent(fallback); else next = null;
    }

    renderStep(container, flow, engine.state, handleAdvance);
  }

  renderStep(container, flow, engine.state, handleAdvance);

  return {
    destroy() { container.innerHTML = ''; },
    getState() { return engine.state; },
  };
}

// Expose global factory for IIFE consumers
// @ts-expect-error - attached by IIFE build
if (typeof window !== 'undefined') window.UnisonWidgetKit = { createFlowApp };


