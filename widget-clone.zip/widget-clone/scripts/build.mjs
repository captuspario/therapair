import { build } from 'esbuild';
import { rmSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const outdir = resolve(process.cwd(), 'dist');

rmSync(outdir, { recursive: true, force: true });
mkdirSync(outdir, { recursive: true });

// ESM bundle for imports
await build({
  entryPoints: ['src/index.ts'],
  outfile: 'dist/index.esm.js',
  bundle: true,
  format: 'esm',
  sourcemap: true,
  target: 'es2020',
  minify: false,
});

// IIFE bundle for <script> tag usage
await build({
  entryPoints: ['src/index.ts'],
  outfile: 'dist/standalone.js',
  bundle: true,
  format: 'iife',
  globalName: 'UnisonWidgetKit',
  sourcemap: true,
  target: 'es2020',
  minify: false,
});

// Lightweight CSS (shipped as inline style in demo; keep empty placeholder if needed later)
writeFileSync('dist/README.txt', 'Build artifacts for Unison Widget Kit');

console.log('Build complete: dist/index.esm.js and dist/standalone.js');


